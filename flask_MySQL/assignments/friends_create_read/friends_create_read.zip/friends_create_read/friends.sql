INSERT INTO friends (first_name, last_name, occupation) 
VALUES('Betty', 'Park', 'Human Resources');

INSERT INTO friends (first_name, last_name, occupation) 
VALUES('Angela', 'Shin', 'English Teacher');

INSERT INTO friends (first_name, last_name, occupation) 
VALUES('Colin', 'Cook', 'Guitarist');

SELECT * from friends