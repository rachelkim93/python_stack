from django.apps import AppConfig


class SessionsConfig(AppConfig):
    name = 'sessions'
