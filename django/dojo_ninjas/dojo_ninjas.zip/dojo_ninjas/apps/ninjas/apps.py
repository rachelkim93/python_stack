from django.apps import AppConfig


class NinjasConfig(AppConfig):
    name = 'ninjas'
