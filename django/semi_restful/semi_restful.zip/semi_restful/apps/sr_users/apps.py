from django.apps import AppConfig


class SemiRestConfig(AppConfig):
    name = 'semi_rest'
