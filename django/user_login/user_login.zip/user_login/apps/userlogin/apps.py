from django.apps import AppConfig


class UserloginConfig(AppConfig):
    name = 'userlogin'
